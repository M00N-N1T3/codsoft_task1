    # with open(dir,"w") as file:
    #     file.writelines(tasks)
    #     file.close()