# a todo list

# write to a file

# print out the list from the file

# we have optional , low, meduim, crucial and high

def menu():

    print("""1) show todo-list\n
2) Add task.
3) Modify task
4) Delete task
5) Complete task
0) Quit""")