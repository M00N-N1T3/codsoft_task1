import platform

import packaging

def install_packages():
    requirements = ["pip","pip3","click",""]

    for imports in requirements:
        try:
            __import__(imports)
        except (ModuleNotFoundError):
            print("not a module")


help(packaging)